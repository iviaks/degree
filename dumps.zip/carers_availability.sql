--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carers_availability; Type: TABLE; Schema: public; Owner: careon
--

CREATE TABLE carers_availability (
    id integer NOT NULL,
    day character varying(50) NOT NULL
);


ALTER TABLE carers_availability OWNER TO careon;

--
-- Name: carers_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: careon
--

CREATE SEQUENCE carers_availability_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE carers_availability_id_seq OWNER TO careon;

--
-- Name: carers_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: careon
--

ALTER SEQUENCE carers_availability_id_seq OWNED BY carers_availability.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_availability ALTER COLUMN id SET DEFAULT nextval('carers_availability_id_seq'::regclass);


--
-- Data for Name: carers_availability; Type: TABLE DATA; Schema: public; Owner: careon
--

COPY carers_availability (id, day) FROM stdin;
1	Monday
2	Tuesday
3	Wednesday
4	Thursday
5	Friday
6	Saturday
7	Sunday
\.


--
-- Name: carers_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: careon
--

SELECT pg_catalog.setval('carers_availability_id_seq', 7, true);


--
-- Name: carers_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_availability
    ADD CONSTRAINT carers_availability_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

