--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carers_caretype; Type: TABLE; Schema: public; Owner: careon
--

CREATE TABLE carers_caretype (
    id integer NOT NULL,
    title character varying(50) NOT NULL
);


ALTER TABLE carers_caretype OWNER TO careon;

--
-- Name: carers_caretype_id_seq; Type: SEQUENCE; Schema: public; Owner: careon
--

CREATE SEQUENCE carers_caretype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE carers_caretype_id_seq OWNER TO careon;

--
-- Name: carers_caretype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: careon
--

ALTER SEQUENCE carers_caretype_id_seq OWNED BY carers_caretype.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_caretype ALTER COLUMN id SET DEFAULT nextval('carers_caretype_id_seq'::regclass);


--
-- Data for Name: carers_caretype; Type: TABLE DATA; Schema: public; Owner: careon
--

COPY carers_caretype (id, title) FROM stdin;
1	Day care
2	Night care
3	Live-in
\.


--
-- Name: carers_caretype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: careon
--

SELECT pg_catalog.setval('carers_caretype_id_seq', 3, true);


--
-- Name: carers_caretype_pkey; Type: CONSTRAINT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_caretype
    ADD CONSTRAINT carers_caretype_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

