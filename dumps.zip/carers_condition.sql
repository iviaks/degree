--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carers_condition; Type: TABLE; Schema: public; Owner: careon
--

CREATE TABLE carers_condition (
    id integer NOT NULL,
    title character varying(50) NOT NULL
);


ALTER TABLE carers_condition OWNER TO careon;

--
-- Name: carers_condition_id_seq; Type: SEQUENCE; Schema: public; Owner: careon
--

CREATE SEQUENCE carers_condition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE carers_condition_id_seq OWNER TO careon;

--
-- Name: carers_condition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: careon
--

ALTER SEQUENCE carers_condition_id_seq OWNED BY carers_condition.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_condition ALTER COLUMN id SET DEFAULT nextval('carers_condition_id_seq'::regclass);


--
-- Data for Name: carers_condition; Type: TABLE DATA; Schema: public; Owner: careon
--

COPY carers_condition (id, title) FROM stdin;
1	Visual Impairment
2	Stroke
3	Depression
4	Autism
6	Orthopaedic Injuries
7	Vascular Dementia
8	Spinal Injury Care
10	Physical Disability
11	Deafness
12	ADHD
13	Language Processing Difficulties
14	Aspergers
15	Motor Neurone Disease
16	COPD
17	Learning Disability
18	Schizophrenia
19	Traumatic Brain Injury
20	Cerebral Palsy
21	Alzheimer's Dementia
23	Terminal Illness
24	Eating Disorder
25	Cancer
26	HIV
27	PDD
28	Global Delay
29	Attachment Disorder
5	Multiple Sclerosis
9	Anxiety
22	Parkinson's Disease
30	Diabetes
31	None of the Above
\.


--
-- Name: carers_condition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: careon
--

SELECT pg_catalog.setval('carers_condition_id_seq', 31, true);


--
-- Name: carers_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_condition
    ADD CONSTRAINT carers_condition_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

