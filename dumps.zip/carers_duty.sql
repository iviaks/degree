--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carers_duty; Type: TABLE; Schema: public; Owner: careon
--

CREATE TABLE carers_duty (
    id integer NOT NULL,
    title character varying(50) NOT NULL
);


ALTER TABLE carers_duty OWNER TO careon;

--
-- Name: carers_duty_id_seq; Type: SEQUENCE; Schema: public; Owner: careon
--

CREATE SEQUENCE carers_duty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE carers_duty_id_seq OWNER TO careon;

--
-- Name: carers_duty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: careon
--

ALTER SEQUENCE carers_duty_id_seq OWNED BY carers_duty.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_duty ALTER COLUMN id SET DEFAULT nextval('carers_duty_id_seq'::regclass);


--
-- Data for Name: carers_duty; Type: TABLE DATA; Schema: public; Owner: careon
--

COPY carers_duty (id, title) FROM stdin;
1	Personal Assistance
3	Driving License (with car)
4	Physical Activities
5	Attending Appointments
6	Driving License
7	Wheelchair Assistance
8	Doing Errands
9	None of the Above
2	Gardening
\.


--
-- Name: carers_duty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: careon
--

SELECT pg_catalog.setval('carers_duty_id_seq', 9, true);


--
-- Name: carers_duty_pkey; Type: CONSTRAINT; Schema: public; Owner: careon
--

ALTER TABLE ONLY carers_duty
    ADD CONSTRAINT carers_duty_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

