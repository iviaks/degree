cat $(ls *.sql) | psql -U careon careon
